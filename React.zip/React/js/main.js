
const field= document.querySelector("#field");
const input= document.querySelector("#input");
const addButton= document.querySelector(".add");
const boldButton = document.querySelector(".bold")
const italicButton = document.querySelector(".italic")
const btnRed= document.getElementById("red");
const btnGreen= document.getElementById("green");
const thrLine = document.getElementById("strikethrough");
const underLine = document.getElementById("underline");
const firstCapital = document.getElementById("firstCapitalLetter");


addButton.addEventListener("click", ()=>{
    field.textContent += input.value;
})
boldButton.addEventListener("click", () =>{
    field.style.fontWeight = "bold";
})
italicButton.addEventListener("click", () =>{
    field.style.fontStyle = "italic";
})
thrLine.addEventListener("click", () =>{
    field.style.textDecorationLine = "line-through";
 })
underLine.addEventListener("click", () =>{
field.style.textDecorationLine = "underline";
})
firstCapital.addEventListener("click", () =>{
    field.style.textTransform = "capitalize";;
    })
btnGreen.addEventListener("click", (e)=>{
    field.style.backgroundColor = "green";
})
btnRed.addEventListener("click", (e)=>{
    field.style.backgroundColor = "red";
})
