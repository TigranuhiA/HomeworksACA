// const line = document.getElementById("li");
// line.addEventListener("click", () =>{
//    ol.style.textDecorationLine = "line-through";
// })

