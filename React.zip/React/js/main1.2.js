const clickButton= document.querySelector("#click");
clickButton.addEventListener("click", () => {
    document.body.style.backgroundColor = "green";
})